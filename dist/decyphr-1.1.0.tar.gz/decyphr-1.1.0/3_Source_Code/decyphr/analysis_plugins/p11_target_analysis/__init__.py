# ==============================================================================
# FILE: 3_Source_Code/decyphr/analysis_plugins/p11_target_analysis/__init__.py
# ==============================================================================
# PURPOSE: This file makes the 'p11_target_analysis' directory a Python package.

# Its presence is essential for the Python interpreter to allow imports
# from this directory, such as:
# from .analysis_plugins.p11_target_analysis import run_analysis

# This file can remain empty.